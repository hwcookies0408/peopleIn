from django.apps import AppConfig


class NoticeConfig(AppConfig):
    name = 'notice'
